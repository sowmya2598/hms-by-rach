﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSException
{
    public class HospitalException:ApplicationException
    {
        public HospitalException() : base() { }

        public HospitalException(string message) : base(message) { }

        public HospitalException(string message, Exception innerException) : base(message, innerException) { }
    }
}
