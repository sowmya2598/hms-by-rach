﻿using HMSDAL;
using HMSEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HMSBLL
{
    public class HospitalBLL
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            try
            {
                if (patient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validPatient = false;
                }
                if (patient.PatientName == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Name is Required");
                    validPatient = false;
                }
                if (patient.Gender == "Select")
                {
                    sb.Append(Environment.NewLine + "Gender Id is Required");
                    validPatient = false;
                }
                if (patient.PhoneNo.Length < 10)
                {
                    sb.Append(Environment.NewLine + "Phone Number should have 10 digits");
                    validPatient = false;
                }
                else if (!Regex.IsMatch(patient.PhoneNo, "[6-9][0-9]{9}"))
                {
                    sb.Append("Phone number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validPatient = false;
                }
                if (patient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validPatient = false;
                }
                if (validPatient == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validPatient;

        }

        private static bool ValidateAppointment(Appointment appointment)
        {
            StringBuilder sb = new StringBuilder();
            bool validAppointment = true;
            try
            {
                if (appointment.AppointmentId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Appointment Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (appointment.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validAppointment = false;
                }
                if (validAppointment == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validAppointment;
        }

        private static bool ValidateBill(Bill bill)
        {
            StringBuilder sb = new StringBuilder();
            bool validBill = true;
            try
            {
                if (bill.BillId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Bill Id is required cannnot be blank");
                    validBill = false;
                }
                if (bill.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is required");
                    validBill = false;
                }
                if (bill.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validBill = false;
                }
                else if (bill.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validBill = false;
                }
                if (validBill == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validBill;
        }

        private static bool ValidateLab(Lab lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLab = true;
            try
            {
                if (lab.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validLab = false;
                }
                if (lab.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validLab = false;
                }
                else if (lab.PatientId == "Select")
                {
                    sb.Append(Environment.NewLine + "Patient Id is Required");
                    validLab = false;
                }
                if (lab.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validLab = false;
                }
                if (validLab == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validLab;
        }

        private static bool ValidateInPatient(InPatient inPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validInPatient = true;
            try
            {
                if (inPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validInPatient = false;
                }
                if (inPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validInPatient = false;
                }
                if (inPatient.RoomId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Room Id is required cannnot be blank");
                    validInPatient = false;
                }

                else if (inPatient.RoomId == "Select")
                {
                    sb.Append(Environment.NewLine + "Room Id is Required");
                    validInPatient = false;
                }
                if (inPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validInPatient = false;
                }
                else if (inPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validInPatient = false;
                }
                if (inPatient.AdmissionDate == null)
                {
                    sb.Append(Environment.NewLine + "Admission Date is Required");
                    validInPatient = false;
                }
                if (inPatient.DischargeDate == null)
                {
                    sb.Append(Environment.NewLine + "Discharge Date is Required");
                    validInPatient = false;
                }
                if (inPatient.AmountPerDay <= 0)
                {
                    sb.Append(Environment.NewLine + "Enter the Amount Per Day");
                    validInPatient = false;
                }
                if (validInPatient == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validInPatient;
        }

        private static bool ValidateOutPatient(OutPatient outPatient)
        {
            StringBuilder sb = new StringBuilder();
            bool validOutPatient = true;
            try
            {
                if (outPatient.LabId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Lab Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.LabId == "Select")
                {
                    sb.Append(Environment.NewLine + "Lab Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.PatientId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Patient Id is required cannnot be blank");
                    validOutPatient = false;
                }
                if (outPatient.DoctorId == string.Empty)
                {
                    sb.Append(Environment.NewLine + "Doctor Id is required cannnot be blank");
                    validOutPatient = false;
                }
                else if (outPatient.DoctorId == "Select")
                {
                    sb.Append(Environment.NewLine + "Doctor Id is Required");
                    validOutPatient = false;
                }
                if (outPatient.TreatmentDate == null)
                {
                    sb.Append(Environment.NewLine + "Treatment Date is Required");
                    validOutPatient = false;
                }
                if (validOutPatient == false)
                    throw new HMSException.HospitalException(sb.ToString());
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validOutPatient;
        }

        public static int AddPatientBLL(Patient newPatient)
        {
            int patientAdded = 0;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = HospitalDAL.AddPatientDAL(newPatient);
                }
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static DataTable GetAllPatientsBLL()
        {
            DataTable dtPatient = null;
            try
            {
                dtPatient = HospitalDAL.GetAllPatientsDAL();
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtPatient;
        }

        public static int DeletePatientBLL(string deletePatientID)
        {
            int patientDeleted = 0;
            try
            {
                if (deletePatientID != null)
                {
                    patientDeleted = HospitalDAL.DeletePatientDAL(deletePatientID);
                }
                else
                {
                    throw new HMSException.HospitalException("Invalid Patient ID");
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static Patient SearchPatientBLL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = HospitalDAL.SearchPatientDAL(searchPatientID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static DataSet SearchPatientByDoctorBLL(string searchPatientID)
        {
            DataSet dataSet = new DataSet();// searchPatient = null;
            try
            {
                dataSet = HospitalDAL.SearchPatientByDoctorDAL(searchPatientID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static int UpdatePatientBLL(Patient updatePatient)
        {
            int patientUpdated = 0;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    //HospitalDAL patientDAL = new HospitalDAL();
                    patientUpdated = HospitalDAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }

        //public static int AddPatientAppointmentBLL(Appointment newAppointment)
        //{
        //    int patientAppointmentAdded = 0;
        //    try
        //    {
        //        if (ValidateAppointment(newAppointment))
        //        {
        //            patientAppointmentAdded = HospitalDAL.AddPatientAppointmentDAL(newAppointment);
        //        }
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAppointmentAdded;
        //}

        //public static DataTable GetAllPatientsAppointmentBLL()
        //{
        //    DataTable dtAppointment = null;
        //    try
        //    {
        //        dtAppointment = HospitalDAL.GetAllPatientsAppointmentDAL();
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dtAppointment;
        //}

        //public static int DeletePatientAppointmentBLL(string deletePatientAppointmentID)
        //{
        //    int patientAppointmentDeleted = 0;
        //    try
        //    {
        //        if (deletePatientAppointmentID != null)
        //        {
        //            patientAppointmentDeleted = HospitalDAL.DeletePatientAppointmentDAL(deletePatientAppointmentID);
        //        }
        //        else
        //        {
        //            throw new HMSException.HMSException("Invalid Patient's Appointment ID");
        //        }
        //    }
        //    catch (HMSException.HMSException)
        //    {
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAppointmentDeleted;
        //}

        //public static Appointment SearchPatientByDoctorBLL(string searchPatientDOC)
        //{
        //    Appointment searchPatientdoc = null;
        //    try
        //    {
        //        searchPatientdoc = HospitalDAL.SearchPatientDoctorDAL(searchPatientDOC);
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatientdoc;

        //}

        //public static Appointment SearchPatientDOVBLL(DateTime searchPatientDOV)
        //{
        //    Appointment searchPatientdov = null;
        //    try
        //    {
        //        searchPatientdov = HospitalDAL.SearchPatientDOVDAL(searchPatientDOV);
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatientdov;

        //}
        //public static Appointment SearchPatientDOABLL(DateTime searchPatientDOA)
        //{
        //    Appointment searchPatientdoa = null;
        //    try
        //    {
        //        searchPatientdoa = HospitalDAL.SearchPatientDODDAL(searchPatientDOA);
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatientdoa;

        //}
        //public static Appointment SearchPatientDODBLL(DateTime searchPatientDOD)
        //{
        //    Appointment searchPatientdod = null;
        //    try
        //    {
        //        searchPatientdod = HospitalDAL.SearchPatientDODDAL(searchPatientDOD);
        //    }
        //    catch (HMSException.HMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchPatientdod;
        //}

        public static int AddPatientBillBLL(Bill newBill)
        {
            int patientBillAdded = 0;
            try
            {
                if (ValidateBill(newBill))
                {
                    patientBillAdded = HospitalDAL.AddPatientBillDAL(newBill);
                }
            }
            catch (HMSException.HospitalException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientBillAdded;
        }

        public static DataTable GetAllPatientBillBLL()
        {
            DataTable billList = null;
            try
            {
                billList = HospitalDAL.GetAllPatientBillDAL();
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billList;
        }

        public static Bill SearchBillByIdBLL(string searchBillID)
        {
            Bill searchBill = null;
            try
            {
                searchBill = HospitalDAL.SearchBillByIdDAL(searchBillID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchBill;
        }

        public static int UpdateBillByIdBLL(Bill updateBill)
        {
            int billUpdated = 0;
            try
            {
                if (ValidateBill(updateBill))
                {
                    //HospitalDAL patientDAL = new HospitalDAL();
                    billUpdated = HospitalDAL.UpdateBillByIdDAL(updateBill);
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return billUpdated;
        }

        public static int DeletePatientBillBLL(string deletePatientBillID)
        {
            int patientBillDeleted = 0;
            try
            {
                if (deletePatientBillID != null)
                {
                    patientBillDeleted = HospitalDAL.DeletePatientBillDAL(deletePatientBillID);
                }
                else
                {
                    throw new HMSException.HospitalException("Invalid Patient's Bill ID");
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientBillDeleted;
        }

        public static int AddPatientLabReportBLL(Lab newLabReport)
        {
            int patientLabReportAdded = 0;
            try
            {
                if (ValidateLab(newLabReport))
                {
                    patientLabReportAdded = HospitalDAL.AddPatientLabReportDAL(newLabReport);
                }
            }
            catch (HMSException.HospitalException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientLabReportAdded;
        }

        public static DataTable GetAllPatientLabReportBLL()
        {
            DataTable labList = null;
            try
            {
                labList = HospitalDAL.GetAllPatientLabReportDAL();
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labList;
        }

        public static Lab SearchReportByIdBLL(string searchReportID)
        {
            Lab searchReport = null;
            try
            {
                searchReport = HospitalDAL.SearchReportByIdDAL(searchReportID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchReport;

        }

        public static int DeletePatientLabReportBLL(string deletePatientLabReportID)
        {
            int patientLabReportDeleted = 0;
            try
            {
                if (deletePatientLabReportID != null)
                {
                    patientLabReportDeleted = HospitalDAL.DeletePatientLabReportDAL(deletePatientLabReportID);
                }
                else
                {
                    throw new HMSException.HospitalException("Invalid Patient's Lab Report ID");
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientLabReportDeleted;
        }

        public static int UpdateLabReportByIdBLL(Lab updateLabReport)
        {
            int labReportUpdated = 0;
            try
            {
                if (ValidateLab(updateLabReport))
                {
                    //HospitalDAL patientDAL = new HospitalDAL();
                    labReportUpdated = HospitalDAL.UpdateLabReportByIdDAL(updateLabReport);
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return labReportUpdated;
        }

        public static int AddInPatientBLL(InPatient newInPatient)
        {
            int inPatientAdded = 0;
            try
            {
                if (ValidateInPatient(newInPatient))
                {
                    inPatientAdded = HospitalDAL.AddInPatientDAL(newInPatient);
                }
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientAdded;
        }

        public static DataTable GetAllInPatientsBLL()
        {
            DataTable dtInPatient = null;
            try
            {
                dtInPatient = HospitalDAL.GetAllInPatientsDAL();
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtInPatient;
        }

        public static InPatient SearchInPatientBLL(string searchPatientID)
        {
            InPatient searchInPatient = null;
            try
            {
                searchInPatient = HospitalDAL.SearchInPatientDAL(searchPatientID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchInPatient;
        }

        public static int UpdateInPatientBLL(InPatient updateInPatient)
        {
            int inPatientUpdated = 0;
            try
            {
                if (ValidateInPatient(updateInPatient))
                {
                    //HospitalDAL patientDAL = new HospitalDAL();
                    inPatientUpdated = HospitalDAL.UpdateInPatientDAL(updateInPatient);
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return inPatientUpdated;
        }

        public static int DeleteInPatientBLL(string deleteInPatientID)
        {
            int inPatientDeleted = 0;
            try
            {
                if (deleteInPatientID != null)
                {
                    inPatientDeleted = HospitalDAL.DeleteInPatientDAL(deleteInPatientID);
                }
                else
                {
                    throw new HMSException.HospitalException("Invalid InPatient ID");
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientDeleted;
        }

        public static DataSet SearchInPatientByDoctorBLL(string searchInPatientByDoctorID)
        {
            DataSet dataSet = new DataSet();// searchPatient = null;
            try
            {
                dataSet = HospitalDAL.SearchInPatientByDoctorDAL(searchInPatientByDoctorID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static DataSet SearchInPatientByRoomBLL(string searchInPatientByRoomID)
        {
            DataSet dataSet = new DataSet();// searchPatient = null;
            try
            {
                dataSet = HospitalDAL.SearchInPatientByRoomDAL(searchInPatientByRoomID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static int AddOutPatientBLL(OutPatient newOutPatient)
        {
            int outPatientAdded = 0;
            try
            {
                if (ValidateOutPatient(newOutPatient))
                {
                    outPatientAdded = HospitalDAL.AddOutPatientDAL(newOutPatient);
                }
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outPatientAdded;
        }

        public static DataTable GetAllOutPatientsBLL()
        {
            DataTable dtOutPatient = null;
            try
            {
                dtOutPatient = HospitalDAL.GetAllOutPatientsDAL();
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtOutPatient;
        }

        public static OutPatient SearchOutPatientBLL(string searchPatientID)
        {
            OutPatient searchOutPatient = null;
            try
            {
                searchOutPatient = HospitalDAL.SearchOutPatientDAL(searchPatientID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchOutPatient;
        }

        public static int DeleteOutPatientBLL(string deleteInPatientID)
        {
            int outPatientDeleted = 0;
            try
            {
                if (deleteInPatientID != null)
                {
                    outPatientDeleted = HospitalDAL.DeleteOutPatientDAL(deleteInPatientID);
                }
                else
                {
                    throw new HMSException.HospitalException("Invalid OutPatient ID");
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outPatientDeleted;
        }

        public static int UpdateOutPatientBLL(OutPatient updateOutPatient)
        {
            int outPatientUpdated = 0;
            try
            {
                if (ValidateOutPatient(updateOutPatient))
                {
                    //HospitalDAL patientDAL = new HospitalDAL();
                    outPatientUpdated = HospitalDAL.UpdateOutPatientDAL(updateOutPatient);
                }
            }
            catch (HMSException.HospitalException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return outPatientUpdated;
        }

        public static DataSet SearchOutPatientByDoctorBLL(string searchOutPatientByDoctorID)
        {
            DataSet dataSet = new DataSet();// searchPatient = null;
            try
            {
                dataSet = HospitalDAL.SearchOutPatientByDoctorDAL(searchOutPatientByDoctorID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static DataSet SearchOutPatientByLabBLL(string searchOutPatientByLabID)
        {
            DataSet dataSet = new DataSet();// searchPatient = null;
            try
            {
                dataSet = HospitalDAL.SearchOutPatientByLabDAL(searchOutPatientByLabID);
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }





        public static List<string> GetDoctorIdsBLL()
        {
            List<string> listObj = null;
            try
            {
                listObj = HospitalDAL.GetDoctorIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetPatientIds()
        {
            List<string> listObj = null;
            try
            {
                listObj = HospitalDAL.GetPatientIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetLabIdsBLL()
        {
            List<string> listObj = null;
            try
            {
                listObj = HospitalDAL.GetLabIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }

        public static List<string> GetRoomIdsBLL()
        {
            List<string> listObj = null;
            try
            {
                listObj = HospitalDAL.GetRoomIdsDAL();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }
    }
}
