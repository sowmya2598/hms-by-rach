﻿using HMSEntities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSDAL
{
    public class HospitalDAL
    {
        //public static List<Patient> patientList = new List<Patient>();
        //public static List<Appointment> appointmentList = new List<Appointment>();
        //public static List<Bill> billList = new List<Bill>();
        //public static List<Lab> labList = new List<Lab>();
        //public static string fileName = "PatientList";
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;
            try
            {
                SqlConnection con = new SqlConnection();
               

                con.ConnectionString = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cmd;
        }

        public static int AddPatientDAL(Patient newPatient)
        {
            int patientAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_insertpatient";
                cmdobj.Parameters.AddWithValue("@pId", newPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@name", newPatient.PatientName);
                cmdobj.Parameters.AddWithValue("@age", newPatient.Age);
                cmdobj.Parameters.AddWithValue("@weight", newPatient.Weight);
                cmdobj.Parameters.AddWithValue("@gender", newPatient.Gender);
                cmdobj.Parameters.AddWithValue("@address", newPatient.Address);
                cmdobj.Parameters.AddWithValue("@phoneno", newPatient.PhoneNo);
                cmdobj.Parameters.AddWithValue("@disease", newPatient.Disease);
                cmdobj.Parameters.AddWithValue("@dId", newPatient.DoctorId);

                cmdobj.Connection.Open();
                patientAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static DataTable GetAllPatientsDAL()
        {
            DataTable dtPatient = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllPatients";

                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtPatient.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtPatient;
        }

        public static int DeletePatientDAL(string deletepatientID)
        {
            int patientDeleted = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_delPatientById";
                cmdobj.Parameters.AddWithValue("@pId", deletepatientID);
                cmdobj.Connection.Open();
                patientDeleted = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static Patient SearchPatientDAL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetPatientById";
                cmdobj.Parameters.AddWithValue("@pId", searchPatientID);
                cmdobj.Connection.Open();
                SqlDataReader drPatient = cmdobj.ExecuteReader();
                if (drPatient.HasRows)
                {
                    searchPatient = new Patient();
                    drPatient.Read();
                    //using column name, retrieving values
                    searchPatient.PatientId = drPatient["PatientID"].ToString();
                    searchPatient.PatientName = drPatient["Name"].ToString();
                    searchPatient.Age = Convert.ToInt32(drPatient["Age"]);
                    searchPatient.Weight = Convert.ToInt32(drPatient["Weight"]);
                    searchPatient.Gender = drPatient["Gender"].ToString();
                    searchPatient.Address = drPatient["Address"].ToString();
                    searchPatient.PhoneNo = drPatient["PhoneNo"].ToString();
                    searchPatient.Disease = drPatient["Disease"].ToString();
                    searchPatient.DoctorId = drPatient["DoctorId"].ToString();
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static DataSet SearchPatientByDoctorDAL(string searchPatientByDoctorID)
        {
            DataSet dataSet = new DataSet();
            //Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetPatientByDoctorId";
                cmdobj.Parameters.AddWithValue("@dId", searchPatientByDoctorID);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dataSet, "Patient");
                cmdobj.Connection.Close();
                //SqlDataReader drPatient = cmdobj.ExecuteReader();
                //if (drPatient.HasRows)
                //{
                //    searchPatient = new Patient();
                //    drPatient.Read();
                //    //using column name, retrieving values
                //    searchPatient.PatientId = drPatient["PatientID"].ToString();
                //    searchPatient.PatientName = drPatient["Name"].ToString();
                //    searchPatient.Age = Convert.ToInt32(drPatient["Age"]);
                //    searchPatient.Weight = Convert.ToInt32(drPatient["Weight"]);
                //    searchPatient.Gender = drPatient["Gender"].ToString();
                //    searchPatient.Address = drPatient["Address"].ToString();
                //    searchPatient.PhoneNo = drPatient["PhoneNo"].ToString();
                //    searchPatient.Disease = drPatient["Disease"].ToString();
                //    searchPatient.DoctorId = drPatient["DoctorId"].ToString();
                //}
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static int UpdatePatientDAL(Patient updatePatient)
        {
            int patientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_UpdatePatientByID";
                cmdobj.Parameters.AddWithValue("@pId", updatePatient.PatientId);
                cmdobj.Parameters.AddWithValue("@name", updatePatient.PatientName);
                cmdobj.Parameters.AddWithValue("@age", updatePatient.Age);
                cmdobj.Parameters.AddWithValue("@weight", updatePatient.Weight);
                cmdobj.Parameters.AddWithValue("@gender", updatePatient.Gender);
                cmdobj.Parameters.AddWithValue("@address", updatePatient.Address);
                cmdobj.Parameters.AddWithValue("@phoneno", updatePatient.PhoneNo);
                cmdobj.Parameters.AddWithValue("@disease", updatePatient.Disease);
                cmdobj.Parameters.AddWithValue("@dId", updatePatient.DoctorId);
                cmdobj.Connection.Open();
                patientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        //public static int AddPatientAppointmentDAL(Appointment newAppointment)
        //{
        //    int appointmentAdded = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_InsertAppointment";
        //        cmdobj.Parameters.AddWithValue("@aid", newAppointment.AppointmentId);
        //        cmdobj.Parameters.AddWithValue("@pid", newAppointment.PatientId);
        //        cmdobj.Parameters.AddWithValue("@dname", newAppointment.DoctorName);
        //        cmdobj.Parameters.AddWithValue("@roomno", newAppointment.RoomNo);
        //        cmdobj.Parameters.AddWithValue("@dateofvisit", newAppointment.DateOfVisit);
        //        cmdobj.Parameters.AddWithValue("@admissiondate", newAppointment.AdmissionDate);
        //        cmdobj.Parameters.AddWithValue("@dischargedate", newAppointment.DischargeDate);
        //        cmdobj.Parameters.AddWithValue("@remarks", newAppointment.Remarks);
        //        cmdobj.Connection.Open();
        //        appointmentAdded = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return appointmentAdded;
        //}

        //public static DataTable GetAllPatientsAppointmentDAL()
        //{
        //    DataTable dtAppointment = new DataTable();
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_GetAllAppointment";

        //        cmdobj.Connection.Open();
        //        SqlDataReader dr = cmdobj.ExecuteReader();
        //        dtAppointment.Load(dr);
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return dtAppointment;
        //}

        //public static int DeletePatientAppointmentDAL(string deletePatientAppointmentID)
        //{
        //    int patientAppointment = 0;
        //    try
        //    {
        //        SqlCommand cmdobj = CreateCommand();
        //        cmdobj.CommandText = "prc_delAppointment";
        //        cmdobj.Parameters.AddWithValue("@pid", deletePatientAppointmentID);
        //        cmdobj.Connection.Open();
        //        patientAppointment = cmdobj.ExecuteNonQuery();
        //        cmdobj.Connection.Close();
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return patientAppointment;
        //}

        //public static Appointment SearchPatientDoctorDAL(string searchPatientDOC)
        //{
        //    Appointment searchPatientdoc = null;
        //    try
        //    {
        //        for (int i = 0; i < patientList.Count; i++)
        //        {
        //            Appointment patient = appointmentList[i];
        //            if (patient.DoctorName == searchPatientDOC)
        //            {
        //                searchPatientdoc = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdoc;
        //}

        //public static Appointment SearchPatientDOVDAL(DateTime searchPatientDOV)
        //{
        //    Appointment searchPatientdov = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.DateOfVisit == searchPatientDOV)
        //            {
        //                searchPatientdov = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdov;
        //}

        //public static Appointment SearchPatientDOADAL(DateTime searchPatientDOA)
        //{
        //    Appointment searchPatientdoa = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.AdmissionDate == searchPatientDOA)
        //            {
        //                searchPatientdoa = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdoa;
        //}

        //public static Appointment SearchPatientDODDAL(DateTime searchPatientDOD)
        //{
        //    Appointment searchPatientdod = null;
        //    try
        //    {
        //        for (int i = 0; i < appointmentList.Count; i++)
        //        {
        //            Appointment appointment = appointmentList[i];
        //            if (appointment.DischargeDate == searchPatientDOD)
        //            {
        //                searchPatientdod = appointmentList[i];
        //                break;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new HMS_Exception.HMS_Exception(ex.Message);
        //    }
        //    return searchPatientdod;
        //}

        public static int AddPatientBillDAL(Bill newBill)
        {
            int billAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_InsertBill";
                cmdobj.Parameters.AddWithValue("@bid", newBill.BillId);
                cmdobj.Parameters.AddWithValue("@pid", newBill.PatientId);
                cmdobj.Parameters.AddWithValue("@ptype", newBill.PatientType);
                cmdobj.Parameters.AddWithValue("@did", newBill.DoctorId);
                cmdobj.Parameters.AddWithValue("@dfees", newBill.DoctorFees);
                cmdobj.Parameters.AddWithValue("@rcharges", newBill.RoomCharges);
                cmdobj.Parameters.AddWithValue("@ocharges", newBill.OperationCharges);
                cmdobj.Parameters.AddWithValue("@medfees", newBill.MedicineFees);
                cmdobj.Parameters.AddWithValue("@totaldays", newBill.TotalDays);
                cmdobj.Parameters.AddWithValue("@labfees", newBill.LabFees);
                cmdobj.Parameters.AddWithValue("@totalamount", newBill.TotalAmount);
                cmdobj.Connection.Open();
                billAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new HMSException.HospitalException(ex.Message);
            }
            return billAdded;
        }

        public static DataTable GetAllPatientBillDAL()
        {
            DataTable dtBill = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllBill";
                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtBill.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtBill;
        }

        public static Bill SearchBillByIdDAL(string searchBillID)
        {
            Bill searchBill = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_searchBillById";
                cmdobj.Parameters.AddWithValue("@billid", searchBillID);
                cmdobj.Connection.Open();
                SqlDataReader drBill = cmdobj.ExecuteReader();
                if (drBill.HasRows)
                {
                    searchBill = new Bill();
                    drBill.Read();
                    //using column name, retrieving values
                    searchBill.BillId = drBill["BillId"].ToString();
                    searchBill.PatientId = drBill["Pid"].ToString();
                    searchBill.PatientType = drBill["PatientType"].ToString();
                    searchBill.DoctorId = drBill["DoctorId"].ToString();
                    searchBill.DoctorFees = Convert.ToInt32(drBill["DoctorFees"]);
                    searchBill.RoomCharges = Convert.ToInt32(drBill["RoomCharge"]);
                    searchBill.OperationCharges = Convert.ToInt32(drBill["OperationCharge"]);
                    searchBill.MedicineFees = Convert.ToInt32(drBill["MedicineFees"]);
                    searchBill.TotalDays = Convert.ToInt32(drBill["TotalDays"]);
                    searchBill.LabFees = Convert.ToInt32(drBill["LabFees"]);
                    searchBill.TotalAmount = Convert.ToInt32(drBill["TotalAmount"]);
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchBill;
        }

        public static int UpdateBillByIdDAL(Bill updateBill)
        {
            int patientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_updateBillById";
                cmdobj.Parameters.AddWithValue("@bid", updateBill.BillId);
                cmdobj.Parameters.AddWithValue("@pid", updateBill.PatientId);
                cmdobj.Parameters.AddWithValue("@ptype", updateBill.PatientType);
                cmdobj.Parameters.AddWithValue("@did", updateBill.DoctorId);
                cmdobj.Parameters.AddWithValue("@dfees", updateBill.DoctorFees);
                cmdobj.Parameters.AddWithValue("@rcharges", updateBill.RoomCharges);
                cmdobj.Parameters.AddWithValue("@ocharges", updateBill.OperationCharges);
                cmdobj.Parameters.AddWithValue("@medfees", updateBill.MedicineFees);
                cmdobj.Parameters.AddWithValue("@totaldays", updateBill.TotalDays);
                cmdobj.Parameters.AddWithValue("@labfees", updateBill.LabFees);
                cmdobj.Parameters.AddWithValue("@totalamount", updateBill.TotalAmount);
                cmdobj.Connection.Open();
                patientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static int DeletePatientBillDAL(string deletePatientBillID)
        {
            int patientBill = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_delPatientBill";
                cmdobj.Parameters.AddWithValue("@bid", deletePatientBillID);
                cmdobj.Connection.Open();
                patientBill = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientBill;
        }

        public static int AddPatientLabReportDAL(Lab newLabReport)
        {
            int labReportAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_InsertLabReport";
                cmdobj.Parameters.AddWithValue("@llabId", newLabReport.LabId);
                cmdobj.Parameters.AddWithValue("@lpId", newLabReport.PatientId);
                cmdobj.Parameters.AddWithValue("@ldId", newLabReport.DoctorId);
                cmdobj.Parameters.AddWithValue("@lTestDate", newLabReport.TestDate);
                cmdobj.Parameters.AddWithValue("@lTestType", newLabReport.TestType);
                cmdobj.Parameters.AddWithValue("@lpType", newLabReport.PatientType);
                cmdobj.Connection.Open();
                labReportAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (Exception ex)
            {
                throw new HMSException.HospitalException(ex.Message);
            }
            return labReportAdded;
        }

        public static DataTable GetAllPatientLabReportDAL()
        {
            DataTable dtLabReport = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllLabReports";
                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtLabReport.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtLabReport;
        }

        public static Lab SearchReportByIdDAL(string searchReportID)
        {
            Lab searchLabReport = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_searchLabReportById";
                cmdobj.Parameters.AddWithValue("@llabId", searchReportID);
                cmdobj.Connection.Open();
                SqlDataReader drLabReport = cmdobj.ExecuteReader();
                if (drLabReport.HasRows)
                {
                    searchLabReport = new Lab();
                    drLabReport.Read();
                    //using column name, retrieving values
                    searchLabReport.LabId = drLabReport["LabId"].ToString();
                    searchLabReport.PatientId = drLabReport["PId"].ToString();
                    searchLabReport.DoctorId = drLabReport["DoctorId"].ToString();
                    searchLabReport.TestDate = Convert.ToDateTime(drLabReport["TestDate"]);
                    searchLabReport.TestType = drLabReport["TestType"].ToString();
                    searchLabReport.PatientType = drLabReport["PatientType"].ToString();
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchLabReport;
        }

        public static int DeletePatientLabReportDAL(string deletePatientLabReportID)
        {
            int labReport = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_delLabReport";
                cmdobj.Parameters.AddWithValue("@llabid", deletePatientLabReportID);
                cmdobj.Connection.Open();
                labReport = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labReport;
        }

        public static int UpdateLabReportByIdDAL(Lab updateLabReport)
        {
            int patientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_UpdateLabReportByID";
                cmdobj.Parameters.AddWithValue("@llabId", updateLabReport.LabId);
                cmdobj.Parameters.AddWithValue("@lpId", updateLabReport.PatientId);
                cmdobj.Parameters.AddWithValue("@ldId", updateLabReport.DoctorId);
                cmdobj.Parameters.AddWithValue("@lTestDate", updateLabReport.TestDate);
                cmdobj.Parameters.AddWithValue("@lTestType", updateLabReport.TestType);
                cmdobj.Parameters.AddWithValue("@lpType", updateLabReport.PatientType);
                cmdobj.Connection.Open();
                patientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }

        public static int AddInPatientDAL(InPatient newInPatient)
        {
            int inPatientAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_insertInPatient";
                cmdobj.Parameters.AddWithValue("@pId", newInPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@roomno", newInPatient.RoomId);
                cmdobj.Parameters.AddWithValue("@dId", newInPatient.DoctorId);
                cmdobj.Parameters.AddWithValue("@admissiondate", newInPatient.AdmissionDate);
                cmdobj.Parameters.AddWithValue("@dischargedate", newInPatient.DischargeDate);
                cmdobj.Parameters.AddWithValue("@labId", newInPatient.LabId);
                cmdobj.Parameters.AddWithValue("@amount", newInPatient.AmountPerDay);
                cmdobj.Connection.Open();
                inPatientAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientAdded;
        }

        public static DataTable GetAllInPatientsDAL()
        {
            DataTable dtInPatient = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllInPatients";

                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtInPatient.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtInPatient;
        }

        public static InPatient SearchInPatientDAL(string searchPatientID)
        {
            InPatient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetInPatientById";
                cmdobj.Parameters.AddWithValue("@pId", searchPatientID);
                cmdobj.Connection.Open();
                SqlDataReader drPatient = cmdobj.ExecuteReader();
                if (drPatient.HasRows)
                {
                    searchPatient = new InPatient();
                    drPatient.Read();
                    //using column name, retrieving values
                    searchPatient.PatientId = drPatient["PatientID"].ToString();
                    searchPatient.RoomId = drPatient["RoomNo"].ToString();
                    searchPatient.DoctorId = drPatient["DoctorId"].ToString();
                    searchPatient.AdmissionDate = Convert.ToDateTime(drPatient["AdmissionDate"]);
                    searchPatient.DischargeDate = Convert.ToDateTime(drPatient["DischargeDate"]);
                    searchPatient.LabId = drPatient["LabId"].ToString();
                    searchPatient.AmountPerDay = Convert.ToInt32(drPatient["AmountPerDay"]);
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static int UpdateInPatientDAL(InPatient updateInPatient)
        {
            int inPatientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_UpdateInPatientByID";
                cmdobj.Parameters.AddWithValue("@pId", updateInPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@roomno", updateInPatient.RoomId);
                cmdobj.Parameters.AddWithValue("@dId", updateInPatient.DoctorId);
                cmdobj.Parameters.AddWithValue("@admissiondate", updateInPatient.AdmissionDate);
                cmdobj.Parameters.AddWithValue("@dischargedate", updateInPatient.DischargeDate);
                cmdobj.Parameters.AddWithValue("@labId", updateInPatient.LabId);
                cmdobj.Parameters.AddWithValue("@amount", updateInPatient.AmountPerDay);
                cmdobj.Connection.Open();
                inPatientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientUpdated;
        }

        public static int DeleteInPatientDAL(string deleteInPatientID)
        {
            int inPatientDeleted = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_delInPatientById";
                cmdobj.Parameters.AddWithValue("@pId", deleteInPatientID);
                cmdobj.Connection.Open();
                inPatientDeleted = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientDeleted;
        }

        public static DataSet SearchInPatientByDoctorDAL(string searchInPatientByDoctorID)
        {
            DataSet dataSet = new DataSet();
            //Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetInPatientByDoctorId";
                cmdobj.Parameters.AddWithValue("@dId", searchInPatientByDoctorID);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dataSet, "InPatient");
                cmdobj.Connection.Close();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static DataSet SearchInPatientByRoomDAL(string searchInPatientByRoomID)
        {
            DataSet dataSet = new DataSet();
            //Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetInPatientByRoomId";
                cmdobj.Parameters.AddWithValue("@roomId", searchInPatientByRoomID);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dataSet, "InPatient");
                cmdobj.Connection.Close();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static int AddOutPatientDAL(OutPatient newOutPatient)
        {
            int inPatientAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_insertOutPatient";
                cmdobj.Parameters.AddWithValue("@pId", newOutPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@treatmentdate", newOutPatient.TreatmentDate);
                cmdobj.Parameters.AddWithValue("@dId", newOutPatient.DoctorId);
                cmdobj.Parameters.AddWithValue("@labId", newOutPatient.LabId);
                cmdobj.Connection.Open();
                inPatientAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inPatientAdded;
        }

        public static DataTable GetAllOutPatientsDAL()
        {
            DataTable dtOutPatient = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllOutPatients";

                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtOutPatient.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtOutPatient;
        }

        public static OutPatient SearchOutPatientDAL(string searchPatientID)
        {
            OutPatient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetOutPatientById";
                cmdobj.Parameters.AddWithValue("@pId", searchPatientID);
                cmdobj.Connection.Open();
                SqlDataReader drPatient = cmdobj.ExecuteReader();
                if (drPatient.HasRows)
                {
                    searchPatient = new OutPatient();
                    drPatient.Read();
                    //using column name, retrieving values
                    searchPatient.PatientId = drPatient["Pid"].ToString();
                    searchPatient.TreatmentDate = Convert.ToDateTime(drPatient["TreatmentDate"]);
                    searchPatient.DoctorId = drPatient["DoctorId"].ToString();
                    searchPatient.LabId = drPatient["LabId"].ToString();
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static int DeleteOutPatientDAL(string deleteInPatientID)
        {
            int outPatientDeleted = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_delOutPatientById";
                cmdobj.Parameters.AddWithValue("@pId", deleteInPatientID);
                cmdobj.Connection.Open();
                outPatientDeleted = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outPatientDeleted;
        }

        public static int UpdateOutPatientDAL(OutPatient updateOutPatient)
        {
            int outPatientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_UpdateOutPatientByID";
                cmdobj.Parameters.AddWithValue("@pId", updateOutPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@treatmentdate", updateOutPatient.TreatmentDate);
                cmdobj.Parameters.AddWithValue("@dId", updateOutPatient.DoctorId);
                cmdobj.Parameters.AddWithValue("@labId", updateOutPatient.LabId);
                cmdobj.Connection.Open();
                outPatientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outPatientUpdated;
        }

        public static DataSet SearchOutPatientByDoctorDAL(string searchOutPatientByDoctorID)
        {
            DataSet dataSet = new DataSet();
            //Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetOutPatientByDoctorId";
                cmdobj.Parameters.AddWithValue("@dId", searchOutPatientByDoctorID);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dataSet, "OutPatient");
                cmdobj.Connection.Close();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }

        public static DataSet SearchOutPatientByLabDAL(string searchOutPatientByLabID)
        {
            DataSet dataSet = new DataSet();
            //Patient searchPatient = null;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetOutPatientByLabId";
                cmdobj.Parameters.AddWithValue("@labId", searchOutPatientByLabID);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dataSet, "OutPatient");
                cmdobj.Connection.Close();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataSet;
        }



        public static List<string> GetDoctorIdsDAL()
        {
            List<string> listOfIds = new List<string>();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetDoctorIDs";
                cmdobj.Connection.Open();
                SqlDataReader drIds = cmdobj.ExecuteReader();
                listOfIds.Add("Select");
                if (drIds.HasRows)
                {
                    while (drIds.Read())
                    {
                        listOfIds.Add(drIds["DoctorId"].ToString());
                    }
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listOfIds;
        }

        public static List<string> GetPatientIdsDAL()
        {
            List<string> listOfIds = new List<string>();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetPatientIDs";
                cmdobj.Connection.Open();
                SqlDataReader drIds = cmdobj.ExecuteReader();
                listOfIds.Add("Select");
                if (drIds.HasRows)
                {
                    while (drIds.Read())
                    {
                        listOfIds.Add(drIds["PatientId"].ToString());
                    }
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listOfIds;
        }

        public static List<string> GetLabIdsDAL()
        {
            List<string> listOfIds = new List<string>();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetLabIDs";
                cmdobj.Connection.Open();
                SqlDataReader drIds = cmdobj.ExecuteReader();
                listOfIds.Add("Select");
                if (drIds.HasRows)
                {
                    while (drIds.Read())
                    {
                        listOfIds.Add(drIds["LabId"].ToString());
                    }
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listOfIds;
        }

        public static List<string> GetRoomIdsDAL()
        {
            List<string> listOfIds = new List<string>();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetRoomIDs";
                cmdobj.Connection.Open();
                SqlDataReader drIds = cmdobj.ExecuteReader();
                listOfIds.Add("Select");
                if (drIds.HasRows)
                {
                    while (drIds.Read())
                    {
                        listOfIds.Add(drIds["RoomNo"].ToString());
                    }
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listOfIds;
        }
    }
}
