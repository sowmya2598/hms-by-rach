﻿using HMSBLL;
using HMSEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for LabWPF.xaml
    /// </summary>
    public partial class LabWPF : Window
    {
        public LabWPF()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }
        private void LoadPatientIds()
        {
            List<string> listofids = HospitalBLL.GetPatientIds();
            lpId.ItemsSource = listofids;
            lpId.Text = "Select";
        }

        private void LoadDoctorIds()
        {
            List<string> listofids = HospitalBLL.GetDoctorIdsBLL();
            ldId.ItemsSource = listofids;
            ldId.Text = "Select";
        }

        private void Clear()
        {
            lLabId.Text = "";
            lpId.Text = "Select";
            ldId.Text = "Select";
            lTestDate.Text = "";
            lTestType.Text = "";
            lPatientType.Text = "";
        }

        private void Btn_Clear_Click(object sender, RoutedEventArgs e)
        {
            lLabId.Text = "";
            lpId.Text = "";
            ldId.Text = "";
            lTestDate.Text = "";
            lTestType.Text = "";
            lPatientType.Text = "";
            lLabId.Focus();
        }
        private void RefreshLabReport()
        {
            DataTable dtLabReport = HospitalBLL.GetAllPatientLabReportBLL();
            if (dtLabReport.Rows.Count > 0)
            {
                dgLabReport.DataContext = dtLabReport;
            }
            else
            {
                MessageBox.Show("No Patient's Lab Details available");
            }
        }

        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            Lab newLab = new Lab();
            try
            {
                newLab.LabId = lLabId.Text;
                newLab.PatientId = lpId.Text;
                newLab.DoctorId = ldId.Text;
                newLab.TestDate = Convert.ToDateTime(lTestDate.Text);
                newLab.TestType = lTestType.Text;
                newLab.PatientType = lPatientType.Text;
                int labInserted = HospitalBLL.AddPatientLabReportBLL(newLab);
                if (labInserted > 0)
                {
                    MessageBox.Show("Patient's Lab Record is added..!");
                    RefreshLabReport();
                    Clear();
                }
                else
                    throw new HMSException.HospitalException("Patient's Lab Record not added..!");
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string delLabReport = lLabId.Text;
            try
            {
                if (delLabReport != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the Patient's Lab Report Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HospitalBLL.DeletePatientLabReportBLL(delLabReport);
                        if (count > 0)
                        {
                            MessageBox.Show("Patient's Lab Report Details Deleted Successfully..!");
                            RefreshLabReport();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("Patient's Lab Report Detail Is Not Deleted..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Lab lab = null;
                if (lLabId.Text == null)
                {
                    MessageBox.Show("Enter the Patient's Lab Report Id to Search..!");
                }
                string labid = lLabId.Text;
                lab = HospitalBLL.SearchReportByIdBLL(labid);
                if (lab != null)
                {
                    lLabId.Text = lab.LabId;
                    lLabId.IsEnabled = false;
                    lpId.Text = lab.PatientId;
                    ldId.Text = lab.DoctorId;
                    lTestDate.Text = Convert.ToDateTime(lab.TestDate).ToShortDateString();
                    lTestType.Text = lab.TestType;
                    lPatientType.Text = lab.PatientType;
                }
                else
                {
                    throw new HMSException.HospitalException("Patient's Lab Report Detail Is Not Available");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Btn_Update_Click(object sender, RoutedEventArgs e)
        {
            Lab newLab = new Lab();
            try
            {
                newLab.LabId = lLabId.Text;
                newLab.PatientId = lpId.Text;
                newLab.DoctorId = ldId.Text;
                newLab.TestDate = Convert.ToDateTime(lTestDate.Text);
                newLab.TestType = lTestType.Text;
                newLab.PatientType = lPatientType.Text;
                int updatedPatientInserted = HospitalBLL.UpdateLabReportByIdBLL(newLab);
                if (updatedPatientInserted > 0)
                {
                    MessageBox.Show("Patient's Lab Report Details Updated Successfully...!");
                    RefreshLabReport();
                    Clear();
                }
                else
                {
                    throw new HMSException.HospitalException("Patient's Lab Report Details Not Updated..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Refresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshLabReport();
            lLabId.IsEnabled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshLabReport();
            LoadPatientIds();
            LoadDoctorIds();
        }
    }
}
