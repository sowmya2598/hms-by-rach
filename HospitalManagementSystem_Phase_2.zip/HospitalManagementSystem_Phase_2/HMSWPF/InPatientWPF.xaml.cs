﻿using HMSBLL;
using HMSEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for InPatientWPF.xaml
    /// </summary>
    public partial class InPatientWPF : Window
    {
        public InPatientWPF()
        {
            InitializeComponent();
        }
        private void Clear()
        {
            pId.Text = "";
            roomId.Text = "Select";
            docId.Text = "Select";
            txtadmdate.Text = "";
            txtdisdate.Text = "";
            txtlabid.Text = "Select";
            txtamt.Text = "";
        }

        private void LoadDoctorIds()
        {
            List<string> listofids = HospitalBLL.GetDoctorIdsBLL();
            docId.ItemsSource = listofids;
            docId.Text = "Select";
        }

        private void LoadLabIds()
        {
            List<string> listofids = HospitalBLL.GetLabIdsBLL();
            txtlabid.ItemsSource = listofids;
            txtlabid.Text = "Select";
        }

        private void LoadRoomIds()
        {
            List<string> listofids = HospitalBLL.GetRoomIdsBLL();
            roomId.ItemsSource = listofids;
            roomId.Text = "Select";
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshInPatient();
            pId.IsEnabled = true;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            pId.Focus();
        }
        private void RefreshInPatient()
        {
            DataTable dtInPatient = HospitalBLL.GetAllInPatientsBLL();
            if (dtInPatient.Rows.Count > 0)
            {
                dgInPatient.DataContext = dtInPatient;
            }
            else
            {
                MessageBox.Show("No InPatient Details available");
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            InPatient newInPatient = new InPatient();
            try
            {
                newInPatient.PatientId = pId.Text;
                newInPatient.RoomId = roomId.Text;
                newInPatient.DoctorId = docId.Text;
                newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                newInPatient.LabId = txtlabid.Text;
                newInPatient.AmountPerDay = Convert.ToInt32(txtamt.Text);
                int inPatientInserted = HospitalBLL.AddInPatientBLL(newInPatient);
                if (inPatientInserted > 0)
                {
                    MessageBox.Show("Patient Record is added..!");
                    RefreshInPatient();
                    Clear();
                }
                else
                    throw new HMSException.HospitalException("Patient record not added..!");
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string delInPatient = pId.Text;
            try
            {
                if (delInPatient != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the InPatient's Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HospitalBLL.DeleteInPatientBLL(delInPatient);
                        if (count > 0)
                        {
                            MessageBox.Show("InPatient's Details Deleted Successfully..!");
                            RefreshInPatient();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("InPatient's Detail Is Not Deleted..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                InPatient inPatient = null;
                if (pId.Text == null)
                    MessageBox.Show("Enter the InPatient Id to Search..!");
                string pid = pId.Text;
                inPatient = HospitalBLL.SearchInPatientBLL(pid);
                if (inPatient != null)
                {
                    pId.Text = inPatient.PatientId;
                    pId.IsEnabled = false;
                    roomId.Text = inPatient.RoomId;
                    docId.Text = inPatient.DoctorId;
                    txtadmdate.Text = Convert.ToDateTime(inPatient.AdmissionDate).ToString();
                    txtdisdate.Text = Convert.ToDateTime(inPatient.DischargeDate).ToString();
                    txtlabid.Text = inPatient.LabId;
                    txtamt.Text = Convert.ToInt32(inPatient.AmountPerDay).ToString();
                }
                else
                {
                    throw new HMSException.HospitalException("InPatient's Detail Is Not Available");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchDoctor_Click(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            string docid = docId.SelectedValue.ToString();
            try
            {
                if (docId.Text == "Select")
                    MessageBox.Show("Enter Doctor Id to Search");
                DataSet dataSet = HospitalBLL.SearchInPatientByDoctorBLL(docid);
                dgInPatient.DataContext = dataSet.Tables["InPatient"];

            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void BtnSearchRoom_Click(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            string roomid = roomId.SelectedValue.ToString();
            try
            {
                if (roomId.Text == "Select")
                    MessageBox.Show("Enter Room Id to Search");
                DataSet dataSet = HospitalBLL.SearchInPatientByRoomBLL(roomid);
                dgInPatient.DataContext = dataSet.Tables["InPatient"];

            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshInPatient();
            LoadDoctorIds();
            LoadLabIds();
            LoadRoomIds();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            InPatient newInPatient = new InPatient();
            try
            {
                newInPatient.PatientId = pId.Text;
                newInPatient.RoomId = roomId.Text;
                newInPatient.DoctorId = docId.Text;
                newInPatient.AdmissionDate = Convert.ToDateTime(txtadmdate.Text);
                newInPatient.DischargeDate = Convert.ToDateTime(txtdisdate.Text);
                newInPatient.LabId = txtlabid.Text;
                newInPatient.AmountPerDay = Convert.ToInt32(txtamt.Text);
                int updatedInPatientInserted = HospitalBLL.UpdateInPatientBLL(newInPatient);
                if (updatedInPatientInserted > 0)
                {
                    MessageBox.Show("InPatient's Detail Updated Successfully...!");
                    RefreshInPatient();
                    Clear();
                }
                else
                {
                    throw new HMSException.HospitalException("InPatient's Details Not Updated..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
