﻿using HMSBLL;
using HMSEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for BillWPF.xaml
    /// </summary>
    public partial class BillWPF : Window
    {
        public BillWPF()
        {
            InitializeComponent();
        }
        private void Clear()
        {
            bbillId.Text = "";
            bpId.Text = "Select";
            bpatientType.Text = "";
            bdId.Text = "Select";
            bDoctorFees.Text = "";
            bRoomCharges.Text = "";
            bOprtnCharges.Text = "";
            bMedBill.Text = "";
            bTotalDays.Text = "";
            bLabFees.Text = "";
            btotalamount.Text = "Auto Generated";
        }

        private void LoadDoctorIds()
        {
            List<string> listofids = HospitalBLL.GetDoctorIdsBLL();
            bdId.ItemsSource = listofids;
            bdId.Text = "Select";
        }

        private void LoadPatientIds()
        {
            List<string> listofids = HospitalBLL.GetPatientIds();
            bpId.ItemsSource = listofids;
            bpId.Text = "Select";
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            RefreshBill();
            bbillId.IsEnabled = true;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Bill newBill = new Bill();
            try
            {
                newBill.BillId = bbillId.Text;
                newBill.PatientId = bpId.Text;
                newBill.PatientType = bpatientType.Text;
                newBill.DoctorId = bdId.Text;
                newBill.DoctorFees = Convert.ToInt32(bDoctorFees.Text);
                newBill.RoomCharges = Convert.ToInt32(bRoomCharges.Text);
                newBill.OperationCharges = Convert.ToInt32(bOprtnCharges.Text);
                newBill.MedicineFees = Convert.ToInt32(bMedBill.Text);
                newBill.TotalDays = Convert.ToInt32(bTotalDays.Text);
                newBill.LabFees = Convert.ToInt32(bLabFees.Text);
                int totalamount = Convert.ToInt32(bDoctorFees.Text) + ((newBill.TotalDays) * (Convert.ToInt32(bRoomCharges.Text))) + Convert.ToInt32(bOprtnCharges.Text) + Convert.ToInt32(bMedBill.Text) + Convert.ToInt32(bLabFees.Text);
                newBill.TotalAmount = Convert.ToInt32(totalamount);
                int billInserted = HospitalBLL.AddPatientBillBLL(newBill);
                if (billInserted > 0)
                {
                    MessageBox.Show("Patient's Bill Detail Added Successfully..!");
                    RefreshBill();
                    Clear();
                }
                else
                    throw new HMSException.HospitalException("Patient's Bill Detail Is Not Added");
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RefreshBill()
        {
            DataTable dtBill = HospitalBLL.GetAllPatientBillBLL();
            if (dtBill.Rows.Count > 0)
            {
                dgBill.DataContext = dtBill;
            }
            else
            {
                MessageBox.Show("No Patient's Bill Details available");
            }
        }
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Bill newBill = new Bill();
            try
            {
                newBill.BillId = bbillId.Text;
                newBill.PatientId = bpId.Text;
                newBill.PatientType = bpatientType.Text;
                newBill.DoctorId = bdId.Text;
                newBill.DoctorFees = Convert.ToInt32(bDoctorFees.Text);
                newBill.RoomCharges = Convert.ToInt32(bRoomCharges.Text);
                newBill.OperationCharges = Convert.ToInt32(bOprtnCharges.Text);
                newBill.MedicineFees = Convert.ToInt32(bMedBill.Text);
                newBill.TotalDays = Convert.ToInt32(bTotalDays.Text);
                newBill.LabFees = Convert.ToInt32(bLabFees.Text);
                int totalamount = Convert.ToInt32(bDoctorFees.Text) + ((newBill.TotalDays)*(Convert.ToInt32(bRoomCharges.Text))) + Convert.ToInt32(bOprtnCharges.Text) + Convert.ToInt32(bMedBill.Text) + Convert.ToInt32(bLabFees.Text);
                newBill.TotalAmount = Convert.ToInt32(totalamount);
                int updatedBillInserted = HospitalBLL.UpdateBillByIdBLL(newBill);
                if (updatedBillInserted > 0)
                {
                    MessageBox.Show("Patient's Bill Detail Updated Successfully...!");
                    RefreshBill();
                    Clear();
                }
                else
                {
                    throw new HMSException.HospitalException("Patient's Bill Detail Not Updated..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Bill bill = null;
                if (bbillId.Text == null)
                    MessageBox.Show("Enter the Patient Id to Search..!");
                string billid = bbillId.Text;
                bill = HospitalBLL.SearchBillByIdBLL(billid);
                if (bill != null)
                {
                    bbillId.Text = bill.BillId;
                    bbillId.IsEnabled = false;
                    bpId.Text = bill.PatientId;
                    bpatientType.Text = bill.PatientType;
                    bdId.Text = bill.DoctorId;
                    bDoctorFees.Text = bill.DoctorFees.ToString();
                    bRoomCharges.Text = bill.RoomCharges.ToString();
                    bOprtnCharges.Text = bill.OperationCharges.ToString();
                    bMedBill.Text = bill.MedicineFees.ToString();
                    bTotalDays.Text = bill.TotalDays.ToString();
                    bLabFees.Text = bill.LabFees.ToString();
                    btotalamount.Text = bill.TotalAmount.ToString();
                    btotalamount.IsEnabled = false;
                }
                else
                {
                    throw new HMSException.HospitalException("Patient's Bill Detail Is Not Available");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string delBill = bbillId.Text;
            try
            {
                if (delBill != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the Patient's Bill Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HospitalBLL.DeletePatientBillBLL(delBill);
                        if (count > 0)
                        {
                            MessageBox.Show("Patient's Bill Detail Deleted Successfully..!");
                            RefreshBill();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("Patient's Detail Is Not Deleted..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshBill();
            btotalamount.IsEnabled = false;
            LoadDoctorIds();
            LoadPatientIds();
        }
    }
}
