﻿using HMSBLL;
using HMSEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for OutPatientWPF.xaml
    /// </summary>
    public partial class OutPatientWPF : Window
    {
        public OutPatientWPF()
        {
            InitializeComponent();
        }
        private void LoadDoctorIds()
        {
            List<string> listofids = HospitalBLL.GetDoctorIdsBLL();
            docId.ItemsSource = listofids;
            docId.Text = "Select";
        }

        private void LoadLabIds()
        {
            List<string> listofids = HospitalBLL.GetLabIdsBLL();
            labid.ItemsSource = listofids;
            labid.Text = "Select";
        }
        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Hide();
        }
        private void Clear()
        {
            pId.Text = "";
            txttreatmentdate.Text = "";
            docId.Text = "";
            labid.Text = "";
            pId.Focus();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            OutPatient newOutPatient = new OutPatient();
            try
            {
                newOutPatient.PatientId = pId.Text;
                newOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                newOutPatient.DoctorId = docId.Text;
                newOutPatient.LabId = labid.Text;
                int inPatientInserted = HospitalBLL.AddOutPatientBLL(newOutPatient);
                if (inPatientInserted > 0)
                {
                    MessageBox.Show("OutPatient's Record is added..!");
                    RefreshOutPatient();
                    Clear();
                }
                else
                    throw new HMSException.HospitalException("OutPatient's record not added..!");
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            string delInPatient = pId.Text;
            try
            {
                if (delInPatient != null)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to delete the OutPatient's Details?", "Hospital Management System", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        int count = HospitalBLL.DeleteOutPatientBLL(delInPatient);
                        if (count > 0)
                        {
                            MessageBox.Show("OutPatient's Details Deleted Successfully..!");
                            RefreshOutPatient();
                            Clear();
                        }
                    }
                    else
                        MessageBox.Show("OutPatient's Detail Is Not Deleted..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OutPatient outPatient = null;
                if (pId.Text == null)
                    MessageBox.Show("Enter the OutPatient Id to Search..!");
                string pid = pId.Text;
                outPatient = HospitalBLL.SearchOutPatientBLL(pid);
                if (outPatient != null)
                {
                    pId.Text = outPatient.PatientId;
                    pId.IsEnabled = false;
                    txttreatmentdate.Text = Convert.ToDateTime(outPatient.TreatmentDate).ToString();
                    docId.Text = outPatient.DoctorId;
                    labid.Text = outPatient.LabId;
                }
                else
                {
                    throw new HMSException.HospitalException("OutPatient's Detail Is Not Available");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchDoctor_Click(object sender, RoutedEventArgs e)
        {
            RefreshOutPatient();
            string docid = docId.SelectedValue.ToString();
            try
            {
                if (docId.Text == "Select")
                    MessageBox.Show("Enter Doctor Id to Search");
                DataSet dataSet = HospitalBLL.SearchOutPatientByDoctorBLL(docid);
                dgOutPatient.DataContext = dataSet.Tables["OutPatient"];
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        {
            RefreshOutPatient();
            string labId = labid.SelectedValue.ToString();
            try
            {
                if (labid.Text == "Select")
                    MessageBox.Show("Enter Lab Id to Search");
                DataSet dataSet = HospitalBLL.SearchOutPatientByLabBLL(labId);
                dgOutPatient.DataContext = dataSet.Tables["OutPatient"];

            }
            catch (HMSException.HospitalException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            OutPatient newOutPatient = new OutPatient();
            try
            {
                newOutPatient.PatientId = pId.Text;
                newOutPatient.TreatmentDate = Convert.ToDateTime(txttreatmentdate.Text);
                newOutPatient.DoctorId = docId.Text;
                newOutPatient.LabId = labid.Text;
                int updatedOutPatientInserted = HospitalBLL.UpdateOutPatientBLL(newOutPatient);
                if (updatedOutPatientInserted > 0)
                {
                    MessageBox.Show("OutPatient's Detail Updated Successfully...!");
                    RefreshOutPatient();
                    Clear();
                }
                else
                {
                    throw new HMSException.HospitalException("OutPatient's Details Not Updated..!");
                }
            }
            catch (HMSException.HospitalException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
            pId.Focus();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {

            Clear();
            RefreshOutPatient();
            pId.IsEnabled = true;
        }
        private void RefreshOutPatient()
        {
            DataTable dtOutPatient = HospitalBLL.GetAllOutPatientsBLL();
            if (dtOutPatient.Rows.Count > 0)
            {
                dgOutPatient.DataContext = dtOutPatient;
            }
            else
            {
                MessageBox.Show("No OutPatient Details available");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshOutPatient();
            LoadDoctorIds();
            LoadLabIds();
        }
    }
    
}
